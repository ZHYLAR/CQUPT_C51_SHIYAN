#ifndef __DISPLAY_H__
#define __DISPLAY_H__

void display(unsigned char Location,Number);

#endif