#ifndef __DELAY_H__
#define __DELAY_H__

void Delay(unsigned int xms);
void Delay10ms(unsigned int c);
#endif
