#ifndef __KEY_H__
#define __KEY_H__

unsigned char Key();

#endif
