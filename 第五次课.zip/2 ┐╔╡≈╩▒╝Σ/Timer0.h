#ifndef __TIMER0_H__
#define __TIMER0_H__

void Timer0Init(void);

#endif
