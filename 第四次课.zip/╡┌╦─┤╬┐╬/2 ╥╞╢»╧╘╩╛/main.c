#include <REGX52.H>
#include "LCD1602.h"
#include "Delay.h"
#include "MatrixKey.h"

	//LCD_ShowChar(1,1,'A');			//在1行1列显示字符A
	//LCD_ShowString(1,3,"Hello");	//在1行3列显示字符串Hello
	//LCD_ShowNum(1,9,1,1);			//在1行9列显示数字66，长度为2
	//LCD_ShowSignedNum(1,12,-88,2);	//在1行12列显示有符号数字-88，长度为2
	//LCD_ShowHexNum(2,1,0xA5,2);		//在2行1列显示十六进制数字0xA5，长度为2
	//LCD_ShowBinNum(2,4,0xA5,8);		//在2行4列显示二进制数字0xA5，长度为8
//	LCD_ShowChar(2,13,0xDF);		//在2行13列显示编码为0xDF的字符
	//LCD_ShowChar(2,14,'C');			//在2行14列显示字符C
	
void main()
{
	unsigned char i;
	unsigned char mod;
	LCD_Init();	
	while(1){
		LCD_ShowChar(1,(i+0)%16,'w');
		LCD_ShowChar(1,(i+1)%16,'e');
		LCD_ShowChar(1,(i+2)%16,'l');
		LCD_ShowChar(1,(i+3)%16,'c');
		LCD_ShowChar(1,(i+4)%16,'o');
		LCD_ShowChar(1,(i+5)%16,'m');
		LCD_ShowChar(1,(i+6)%16,'e');
		LCD_ShowChar(1,(i+7)%16,' ');
		LCD_ShowChar(1,(i+8)%16,'t');
		LCD_ShowChar(1,(i+9)%16,'o');
		LCD_ShowChar(1,(i+10)%16,' ');
		LCD_ShowChar(1,(i+11)%16,'c');
		LCD_ShowChar(1,(i+12)%16,'q');
		LCD_ShowChar(1,(i+13)%16,'u');
		LCD_ShowChar(1,(i+14)%16,'p');
		LCD_ShowChar(1,(i+15)%16,'t');
		Delay(1000);
		i++;
		if(i==16){
			i=1;
		}
	}
}
